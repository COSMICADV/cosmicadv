# COSMiC — /ai-creativity

A separate page for AI Creativity, opened from the Solutions card on the
homepage. Two parts:

1. **The scroll-scrubbed COSMiC film** — now the page hero.
2. **The work** — six pieces, one per screen, gently snapped so nothing gets
   scrolled past before it has been watched.

Drop-in for Next.js + Tailwind. **Zero new dependencies.** Every class is
namespaced (`cxai-` / `cxwk-`) and each component injects its own `<style>`
once, so nothing outside the page is touched.

---

## 1. Copy the files

```
components/AiCreativity.jsx
components/AiWorkGrid.jsx
app/ai-creativity/page.jsx          ← App Router
                                      (Pages Router: pages/ai-creativity.jsx,
                                       drop the `metadata` export, use next/head)

public/ai-creativity/               ← hero frame sequence (in this zip)
    desktop/f000.webp … f079.webp   1200×675, 80 files, 1.44 MB
    mobile/f000.webp  … f076.webp    720×405, 77 files, 0.79 MB
    poster.webp

public/ai-work/                     ← the six films
    01-seasonal-film.mp4 / .webp
    02-apparel-teaser.mp4 / .webp
    03-beverage-film.mp4 / .webp
    04-apparel-ecommerce.mp4 / .webp
    05-apparel-social.mp4 / .webp
    06-motion-banner.mp4 / .webp
```

**The `public/ai-work/` files are not in this zip** (they are 24 MB). They are
already on your machine, web-ready, at:

```
Cosmic/Portofolio ai/_web/ai-work/
```

Copy that folder's contents into `public/ai-work/`. The originals in
`Portofolio ai/` are untouched.

## 2. Point the homepage Solutions card at the page

The only change to the existing homepage — the `Ai Creativity` card in
`<section id="services">` becomes a link:

```jsx
import Link from 'next/link';

<Link href="/ai-creativity" className="…your existing card classes…">
  <h2>Ai Creativity</h2>
  <p>Redefining the future of content.</p>
</Link>
```

Nothing else on the homepage changes. The scrub section does **not** go on the
homepage — it lives at the top of the new page.

### Props

`AiCreativity` — `href` (default `'/reviews'`), `ctaLabel`, `ctaArrow`,
`dimHeader` (default `true`), `basePath` (default `'/ai-creativity'`).
The page passes `href="#work"`, `ctaLabel="See the work"`, `ctaArrow="↓"`.

`AiWorkGrid` — `basePath` (default `'/ai-work'`), `contactHref`
(default `'/#contact-me'`).

---

## The work: titles and copy

All six are labelled generically — **no client names anywhere**, per your call.
Everything lives in one `WORK` array at the top of `AiWorkGrid.jsx`; edit the
`title`, `meta` and `caption` strings there and nothing else needs touching.

| # | Title | Source file |
|---|---|---|
| 01 | Seasonal Campaign Film | `Eid final.mp4` |
| 02 | Apparel Campaign Teaser | `hf_20260729_…_1.mp4` |
| 03 | Beverage Brand Film | `Kazooza 2_4.mp4` |
| 04 | E-Commerce Reel | `Wilo 1080X1920_1_1_5.mp4` |
| 05 | Social Reel | `wilo reel 3_1_1.mp4` |
| 06 | Motion Banner | `banner.mp4` |

---

## How the pacing works

- Each piece sits in its own `100svh` panel with
  `scroll-snap-align: center`, and the page gets
  `scroll-snap-type: y proximity` — a **gentle** pull that settles the viewer
  on each film without trapping them. If you want it firmer, change
  `proximity` to `mandatory` on the `html.cxwk-page` rule; that is the only
  edit needed, but mandatory snapping fights trackpads on some machines, which
  is why it is not the default.
- A piece plays **only while it is at least half on screen**, muted and looping,
  and pauses the moment it leaves. Never more than one video runs at a time.
- Clicking a film (or its `Sound on` chip) unmutes it and mutes whatever else
  was audible, so two soundtracks can never overlap. Scrolling away re-mutes.
- The dot rail on the right marks position in the set and is clickable.

## Weight

The six films were re-encoded from **180 MB down to 24 MB** (720p / 720×1280,
H.264 CRF 26, `faststart`) with a WebP poster each. Nothing downloads until a
panel is within 1.5 viewports: `preload="none"` and the source is attached
lazily. Landing on the page and staying at the top fetches **zero** video.

The hero is a WebP frame sequence painted on a canvas — no `<video>`, so it
cannot autoplay and does not hit the `currentTime` seek stutter that breaks
video scrubbing on iOS. 1.44 MB desktop / 0.79 MB mobile, lighter than the
original 4.9 MB clip.

## The header

On arrival the white header stays put, so the nav is available. Once the
visitor has scrolled ~8 % into the film it fades out for the cinematic stretch
and returns on the way back up — using the header's own `transition-opacity`,
via a single page-scoped rule (`html.cxai-immersive header { opacity: 0 }`)
that is removed on unmount. `dimHeader={false}` disables it entirely.

After the hero the page is white, matching the site exactly, so the header
returns onto a background it was designed for.

## Reduced motion

`prefers-reduced-motion: reduce` un-pins the hero and renders its final frame
statically, turns snapping off, collapses the panels to content height, and
stops all autoplay — every film becomes a poster the visitor can start
themselves.

---

## Verified before handoff

Headless Chromium, 1440×900 and 390×844 @2×. Because headless Chromium cannot
decode H.264, the playback logic was re-verified against a WebM build of the
same page; layout, scrubbing and loading were tested on the real build.

| check | result |
|---|---|
| hero frame index monotonic 0→100 % and back | pass |
| landing at the top of the page: videos loaded / playing | 0 / 0 |
| each panel autoplays when centred, muted | pass, 6/6 |
| concurrent videos playing, at any point | never more than 1 |
| video + caption both fully in viewport, no overlap | pass, 6/6, both breakpoints |
| unmuting a second film mutes the first | pass |
| audio playing off-screen | none |
| at the closing CTA: videos still playing | 0 |
| lazy load: sources attached only as panels approach | pass (3→4→5→6) |
| header visible at 0 %, faded by 12 %, restored on scroll back | pass |
| console errors | none |

## What was deliberately left alone

Header, navigation, footer, typography scale, Tailwind config, colour tokens,
and every existing homepage section apart from turning the Solutions
`Ai Creativity` card into a link.
