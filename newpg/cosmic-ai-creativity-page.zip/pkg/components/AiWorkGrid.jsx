'use client';

/**
 * COSMiC — AI work portfolio
 *
 * One piece per screen, gently snapped, so nothing can be scrolled past
 * before it has been seen. Muted loop while in view, click for sound.
 * Zero dependencies.
 *
 * Assets expected in /public/ai-work/:
 *   01-seasonal-film.mp4 / .webp   … 06-motion-banner.mp4 / .webp
 */

import { useEffect, useRef } from 'react';

export const WORK = [
  {
    id: '01-seasonal-film',
    title: 'Seasonal Campaign Film',
    meta: 'Brand film · 16:9 · 0:24',
    caption:
      'A holiday spot built end to end with generative video — cast, wardrobe, location and light, none of them booked.',
    ratio: '16 / 9',
  },
  {
    id: '02-apparel-teaser',
    title: 'Apparel Campaign Teaser',
    meta: 'Paid social · 9:16 · 0:03',
    caption:
      'A three-second stopper for the feed. Product on-model, on-location, shot without either.',
    ratio: '9 / 16',
  },
  {
    id: '03-beverage-film',
    title: 'Beverage Brand Film',
    meta: 'Brand film · 9:16 · 0:41',
    caption:
      'Long-form vertical storytelling — a street, a summer and a payoff, at a runtime social usually cannot afford.',
    ratio: '9 / 16',
  },
  {
    id: '04-apparel-ecommerce',
    title: 'E-Commerce Reel',
    meta: 'Performance · 9:16 · 0:25',
    caption:
      'From ad click to unboxing in one continuous piece, built to be re-cut for every product drop.',
    ratio: '9 / 16',
  },
  {
    id: '05-apparel-social',
    title: 'Social Reel',
    meta: 'Always-on · 9:16 · 0:27',
    caption:
      'Everyday, unstaged, in-feed. The kind of footage that used to need a casting call.',
    ratio: '9 / 16',
  },
  {
    id: '06-motion-banner',
    title: 'Motion Banner',
    meta: 'Display · 16:9 · 0:10',
    caption:
      'A looping brand banner — abstract, weightless and light enough to sit on any page.',
    ratio: '16 / 9',
  },
];

const CSS = `
/* gentle snap, scoped to this page only */
html.cxwk-page{scroll-snap-type:y proximity}

.cxwk{background:#fff;color:#000;position:relative}
.cxwk *{box-sizing:border-box}

.cxwk__intro{max-width:1200px;margin:0 auto;padding:clamp(88px,14vh,170px) clamp(20px,5vw,64px) clamp(56px,9vh,110px)}
.cxwk__kicker{font-family:Eurostile,system-ui,sans-serif;font-weight:500;font-size:11px;
  letter-spacing:.42em;text-transform:uppercase;color:#8a8a8a;margin:0 0 26px}
.cxwk__lede{font-family:Eurostile,system-ui,sans-serif;font-weight:700;
  font-size:clamp(26px,3.6vw,52px);line-height:1.16;letter-spacing:-.015em;margin:0;max-width:19ch}
.cxwk__body{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:clamp(20px,3vw,54px);
  margin-top:clamp(34px,5vh,58px);max-width:860px}
.cxwk__body p{font-family:Eurostile,system-ui,sans-serif;font-size:15px;line-height:1.75;
  color:#5b5b5b;margin:0}
@media (max-width:767px){.cxwk__body{grid-template-columns:1fr;gap:18px}}

/* panels */
/* top padding clears the site's 132px fixed header; the extra weight at the
   top also keeps each piece optically centred rather than mathematically */
.cxwk__panel{min-height:100vh;min-height:100svh;scroll-snap-align:center;
  display:flex;align-items:center;justify-content:center;
  padding:clamp(120px,17vh,168px) clamp(20px,5vw,64px) clamp(70px,10vh,110px)}
.cxwk__inner{width:100%;max-width:1200px;display:grid;align-items:center;
  gap:clamp(28px,4.5vw,72px)}
.cxwk__panel[data-orient="portrait"] .cxwk__inner{grid-template-columns:auto minmax(0,36ch);
  justify-content:center}
.cxwk__panel[data-orient="landscape"] .cxwk__inner{grid-template-columns:minmax(0,1fr);
  justify-items:center}

.cxwk__media{position:relative;background:#f2f2f2;overflow:hidden;justify-self:center;
  box-shadow:0 24px 60px -28px rgba(0,0,0,.32)}
.cxwk__panel[data-orient="portrait"] .cxwk__media{aspect-ratio:9/16;
  height:min(calc(100svh - 300px),620px)}
.cxwk__panel[data-orient="landscape"] .cxwk__media{aspect-ratio:16/9;
  width:min(100%,880px)}
.cxwk__media video{width:100%;height:100%;object-fit:cover;display:block;background:#f2f2f2}

.cxwk__sound{position:absolute;right:14px;bottom:14px;z-index:2;
  font-family:Eurostile,system-ui,sans-serif;font-weight:700;font-size:10px;
  letter-spacing:.22em;text-transform:uppercase;color:#fff;
  background:rgba(0,0,0,.42);backdrop-filter:blur(6px);
  border:1px solid rgba(255,255,255,.34);padding:9px 13px;cursor:pointer;
  transition:background .3s ease,color .3s ease}
.cxwk__sound:hover{background:#fff;color:#000;border-color:#fff}
.cxwk__sound:focus-visible{outline:2px solid #000;outline-offset:3px}

.cxwk__text{max-width:38ch}
.cxwk__panel[data-orient="landscape"] .cxwk__text{max-width:880px;width:100%;
  display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:clamp(20px,3vw,54px);align-items:start}
@media (max-width:900px){
  .cxwk__panel[data-orient="landscape"] .cxwk__text{grid-template-columns:1fr;gap:14px}
}
.cxwk__index{font-family:Eurostile,system-ui,sans-serif;font-weight:500;font-size:11px;
  letter-spacing:.34em;color:#9a9a9a;margin:0 0 18px;font-variant-numeric:tabular-nums}
.cxwk__title{font-family:Eurostile,system-ui,sans-serif;font-weight:700;
  font-size:clamp(21px,2.4vw,34px);line-height:1.15;letter-spacing:-.01em;margin:0 0 12px}
.cxwk__meta{font-family:Eurostile,system-ui,sans-serif;font-size:11px;letter-spacing:.2em;
  text-transform:uppercase;color:#9a9a9a;margin:0 0 20px}
.cxwk__caption{font-family:Eurostile,system-ui,sans-serif;font-size:15px;line-height:1.75;
  color:#5b5b5b;margin:0}

/* side rail */
.cxwk__rail{position:fixed;right:clamp(16px,2.2vw,34px);top:50%;transform:translateY(-50%);
  z-index:30;display:flex;flex-direction:column;gap:11px;opacity:0;transition:opacity .45s ease;
  pointer-events:none}
.cxwk__rail.is-on{opacity:1;pointer-events:auto}
.cxwk__rail button{width:22px;height:22px;padding:0;border:0;background:none;cursor:pointer;
  display:grid;place-items:center}
.cxwk__rail i{display:block;width:6px;height:6px;border-radius:50%;background:#c9c9c9;
  transition:background .35s ease,transform .35s ease}
.cxwk__rail button[aria-current="true"] i{background:#000;transform:scale(1.5)}
.cxwk__rail button:focus-visible{outline:2px solid #000;outline-offset:2px}
@media (max-width:900px){.cxwk__rail{display:none}}

/* closing */
.cxwk__end{border-top:1px solid #e8e8e8;padding:clamp(80px,13vh,150px) clamp(20px,5vw,64px);
  display:flex;flex-direction:column;align-items:center;gap:24px;text-align:center}
.cxwk__end h2{font-family:Eurostile,system-ui,sans-serif;font-weight:700;
  font-size:clamp(24px,3.2vw,44px);line-height:1.15;letter-spacing:-.015em;margin:0}
.cxwk__end p{font-family:Eurostile,system-ui,sans-serif;font-size:15px;line-height:1.7;
  color:#6b6b6b;margin:0;max-width:44ch}
.cxwk__cta{display:inline-flex;align-items:center;gap:14px;margin-top:6px;
  font-family:Eurostile,system-ui,sans-serif;font-weight:700;font-size:12px;
  letter-spacing:.26em;text-transform:uppercase;color:#fff;background:#000;
  padding:16px 28px;text-decoration:none;border:1px solid #000;
  transition:background .35s ease,color .35s ease}
.cxwk__cta span{transition:transform .35s cubic-bezier(.2,.8,.2,1)}
.cxwk__cta:hover{background:transparent;color:#000}
.cxwk__cta:hover span{transform:translateX(7px)}

@media (max-width:767px){
  .cxwk__panel{min-height:auto;padding:clamp(48px,8vh,72px) 20px;scroll-snap-align:center}
  .cxwk__panel[data-orient="portrait"] .cxwk__media{height:auto}
  .cxwk__panel .cxwk__inner{grid-template-columns:1fr!important;gap:26px;justify-items:stretch}
  .cxwk__panel[data-orient="portrait"] .cxwk__media{height:auto;width:100%;max-width:420px;
    margin:0 auto;aspect-ratio:9/16}
  .cxwk__panel[data-orient="landscape"] .cxwk__media{max-height:none}
  .cxwk__text{max-width:none}
}

@media (prefers-reduced-motion:reduce){
  html.cxwk-page{scroll-snap-type:none}
  .cxwk__panel{min-height:auto;scroll-snap-align:none;padding:clamp(48px,8vh,80px) 20px}
  .cxwk__rail{display:none}
}
`;

export default function AiWorkGrid({
  basePath = '/ai-work',
  contactHref = '/#contact-me',
}) {
  const rootRef = useRef(null);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;

    if (!document.getElementById('cxwk-styles')) {
      const s = document.createElement('style');
      s.id = 'cxwk-styles';
      s.textContent = CSS;
      document.head.appendChild(s);
    }
    document.documentElement.classList.add('cxwk-page');

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const panels = [...root.querySelectorAll('.cxwk__panel')];
    const rail = root.querySelector('.cxwk__rail');
    const dots = rail ? [...rail.querySelectorAll('button')] : [];

    /* ---- sound: only ever one unmuted ---- */
    const syncSound = (v) => {
      const btn = v.closest('.cxwk__media')?.querySelector('.cxwk__sound');
      if (!btn) return;
      btn.textContent = v.muted ? 'Sound on' : 'Sound off';
      btn.setAttribute('aria-pressed', String(!v.muted));
    };

    /* ---- lazy source attach: one viewport out, so nothing downloads early ---- */
    const lazy = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (!e.isIntersecting) return;
          const v = e.target.querySelector('video');
          if (v && !v.src && v.dataset.src) v.src = v.dataset.src;
          lazy.unobserve(e.target);
        });
      },
      { rootMargin: '150% 0px' }
    );
    panels.forEach((p) => lazy.observe(p));

    /* ---- play only what is on screen ---- */
    let playObserver = null;
    if (!reduced) {
      playObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach((e) => {
            const media = e.target.querySelector('.cxwk__media');
            const v = e.target.querySelector('video');
            if (!v) return;
            if (e.isIntersecting) {
              if (!v.src && v.dataset.src) v.src = v.dataset.src;
              const p = v.play();
              if (p && p.catch) p.catch(() => {});
              media.classList.add('is-playing');
            } else {
              v.pause();
              if (!v.muted) { v.muted = true; syncSound(v); }
            }
          });
        },
        { threshold: 0.5 }
      );
      panels.forEach((p) => playObserver.observe(p));
    }

    const allVideos = [...root.querySelectorAll('video')];
    // Only ever resume a video the visitor can actually see, so a stale
    // toggle can never leave audio playing off-screen.
    const onScreen = (v) => {
      const r = v.getBoundingClientRect();
      return r.bottom > window.innerHeight * 0.25 && r.top < window.innerHeight * 0.75;
    };
    const toggleSound = (v) => {
      const turningOn = v.muted;
      allVideos.forEach((o) => {
        if (o !== v && !o.muted) { o.muted = true; syncSound(o); }
      });
      v.muted = !turningOn;
      if (turningOn && onScreen(v)) {
        const p = v.play();
        if (p && p.catch) p.catch(() => {});
      }
      syncSound(v);
    };

    const onClick = (ev) => {
      const btn = ev.target.closest('.cxwk__sound');
      const media = ev.target.closest('.cxwk__media');
      if (!media) return;
      const v = media.querySelector('video');
      if (!v) return;
      if (btn || ev.target.tagName === 'VIDEO' || ev.target.tagName === 'IMG') {
        ev.preventDefault();
        toggleSound(v);
      }
    };
    root.addEventListener('click', onClick);

    /* ---- side rail ---- */
    let railObserver = null;
    if (dots.length) {
      railObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach((e) => {
            const i = panels.indexOf(e.target);
            if (i < 0) return;
            if (e.isIntersecting && e.intersectionRatio > 0.5) {
              dots.forEach((d, j) => d.setAttribute('aria-current', String(j === i)));
              rail.classList.add('is-on');
            }
          });
          const anyVisible = panels.some((p) => {
            const r = p.getBoundingClientRect();
            return r.top < window.innerHeight * 0.6 && r.bottom > window.innerHeight * 0.4;
          });
          rail.classList.toggle('is-on', anyVisible);
        },
        { threshold: [0, 0.5, 0.9] }
      );
      panels.forEach((p) => railObserver.observe(p));
      dots.forEach((d, i) =>
        d.addEventListener('click', () =>
          panels[i].scrollIntoView({ behavior: 'smooth', block: 'center' })
        )
      );
    }

    allVideos.forEach(syncSound);

    return () => {
      document.documentElement.classList.remove('cxwk-page');
      root.removeEventListener('click', onClick);
      lazy.disconnect();
      playObserver && playObserver.disconnect();
      railObserver && railObserver.disconnect();
    };
  }, [basePath]);

  return (
    <section className="cxwk" id="work" ref={rootRef}>
      <div className="cxwk__intro">
        <p className="cxwk__kicker">Selected AI work</p>
        <h2 className="cxwk__lede">Ideas first. The camera was optional.</h2>
        <div className="cxwk__body">
          <p>
            We use generative AI the way we use a lens or a pen — as a tool in the hands of
            people who already know what a good idea looks like. Every piece below started
            as a brief, a script and a board.
          </p>
          <p>
            What changed is the distance between the idea and the visual. No location scout,
            no crew call, no six-week turnaround — so the budget goes into the thinking
            instead of the logistics.
          </p>
        </div>
      </div>

      {WORK.map((w, i) => (
        <article
          className="cxwk__panel"
          key={w.id}
          data-orient={w.ratio === '9 / 16' ? 'portrait' : 'landscape'}
        >
          <div className="cxwk__inner">
            <div className="cxwk__media">
              <video
                data-src={`${basePath}/${w.id}.mp4`}
                poster={`${basePath}/${w.id}.webp`}
                muted
                loop
                playsInline
                preload="none"
                aria-label={w.title}
              />
              <button className="cxwk__sound" type="button" aria-pressed="false">
                Sound on
              </button>
            </div>
            <div className="cxwk__text">
              <div>
                <p className="cxwk__index">
                  {String(i + 1).padStart(2, '0')} / {String(WORK.length).padStart(2, '0')}
                </p>
                <h3 className="cxwk__title">{w.title}</h3>
                <p className="cxwk__meta">{w.meta}</p>
              </div>
              <p className="cxwk__caption">{w.caption}</p>
            </div>
          </div>
        </article>
      ))}

      <nav className="cxwk__rail" aria-label="Work navigation">
        {WORK.map((w, i) => (
          <button key={w.id} type="button" aria-current={i === 0} aria-label={w.title}>
            <i />
          </button>
        ))}
      </nav>

      <div className="cxwk__end">
        <h2>Have something in mind?</h2>
        <p>
          Bring us the idea. We will show you what it looks like before you commit a
          production budget to it.
        </p>
        <a className="cxwk__cta" href={contactHref}>
          Start a project <span aria-hidden="true">→</span>
        </a>
      </div>
    </section>
  );
}
