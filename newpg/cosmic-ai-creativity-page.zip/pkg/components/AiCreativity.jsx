'use client';

/**
 * COSMiC — AI CREATIVITY
 * Scroll-scrubbed cinematic section.
 *
 * Zero dependencies. Vanilla rAF frame-scrubbing on a <canvas> fed by a
 * pre-decoded WebP frame sequence (no <video>, no autoplay, no seek latency).
 *
 * Assets expected in /public:
 *   /ai-creativity/desktop/f000.webp … f079.webp   (1200×675, 80 files, ~1.4 MB)
 *   /ai-creativity/mobile/f000.webp  … f076.webp   ( 720×405, 77 files, ~0.8 MB)
 *   /ai-creativity/poster.webp                     (final frame, reduced-motion + LCP)
 *
 * Usage (homepage, directly after <section id="services">):
 *   import AiCreativity from '@/components/AiCreativity';
 *   <AiCreativity />
 *
 * Everything is namespaced under `cxai-` and injected once, so it cannot
 * touch the existing COSMiC design system.
 */

import { useEffect, useRef } from 'react';

/* ------------------------------------------------------------------ *
 * Frame maps: 121 timeline slots -> asset file index.
 * Static holds at head/tail reuse the same file, which is why the
 * whole sequence is 80 files instead of 121.
 * ------------------------------------------------------------------ */
const MAP_DESKTOP = [0,0,0,0,0,0,0,0,0,0,0,1,1,2,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,74,74,75,75,75,76,76,76,76,77,77,77,77,77,77,77,77,78,78,78,78,78,78,78,78,78,78,78,78,78,78,78,78,79];
const MAP_MOBILE  = [0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,3,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,73,73,73,74,74,74,74,74,74,75,75,75,75,75,75,75,75,75,75,75,75,75,75,75,75,75,75,75,75,75,75,75,75,76];

const SETS = {
  desktop: { dir: 'desktop', map: MAP_DESKTOP, w: 1200, h: 675 },
  mobile:  { dir: 'mobile',  map: MAP_MOBILE,  w: 720,  h: 405 },
};

/* Chapter labels — appear and dissolve on scroll progress. Kept in the
   corners so they never sit on top of the visual. */
const CHAPTERS = [
  { t: '01 — PROMPT',    in: 0.14, out: 0.32 },
  { t: '02 — SYNTHESIS', in: 0.36, out: 0.56 },
  { t: '03 — FORM',      in: 0.60, out: 0.76 },
];

const clamp  = (v, a = 0, b = 1) => (v < a ? a : v > b ? b : v);
const range  = (v, a, b) => clamp((v - a) / (b - a));
const smooth = (t) => t * t * (3 - 2 * t);

const CSS = `
.cxai{position:relative;background:#000;color:#fff;isolation:isolate}
.cxai *{box-sizing:border-box}
.cxai__track{position:relative;height:230vh}
@supports (height:100svh){.cxai__track{height:calc(100svh + 130vh)}}
.cxai__stage{position:sticky;top:0;height:100vh;height:100svh;width:100%;overflow:hidden;
  background:#000;display:grid;place-items:center}
.cxai__canvas{position:absolute;inset:0;width:100%;height:100%;display:block;
  will-change:transform;transform:translateZ(0);opacity:0;transition:opacity .6s ease}
.cxai.is-ready .cxai__canvas{opacity:1}
.cxai__grain{position:absolute;inset:-50%;pointer-events:none;opacity:.05;mix-blend-mode:overlay;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='140' height='140'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='3'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")}
.cxai__vig{position:absolute;inset:0;pointer-events:none;
  background:radial-gradient(120% 90% at 50% 45%,transparent 45%,rgba(0,0,0,.55) 100%)}
.cxai__scrim{position:absolute;left:0;right:0;bottom:0;height:34%;pointer-events:none;
  background:linear-gradient(180deg,transparent,rgba(0,0,0,.55))}
.cxai__ui{position:absolute;inset:0;pointer-events:none;z-index:2}
.cxai__ui a{pointer-events:auto}

/* type */
.cxai__eyebrow{font-family:Eurostile,"Eurostile Becker Heavy",system-ui,sans-serif;
  font-weight:500;font-size:11px;letter-spacing:.42em;text-transform:uppercase;
  color:rgba(255,255,255,.62);margin:0}
.cxai__title{font-family:Eurostile,"Eurostile Becker Heavy",system-ui,sans-serif;
  font-weight:900;font-size:clamp(19px,2.6vw,34px);line-height:1;letter-spacing:.2em;
  text-transform:uppercase;margin:0;color:#fff;text-indent:.2em}

/* intro — sits in the lower third so frame 0 (the COSMiC logo) stays the hero */
.cxai__intro{position:absolute;left:0;right:0;top:68%;
  display:flex;flex-direction:column;align-items:center;gap:20px;text-align:center;padding:0 24px}
.cxai__hint{display:flex;flex-direction:column;align-items:center;gap:12px}
.cxai__rule{width:1px;height:46px;background:linear-gradient(180deg,rgba(255,255,255,.7),transparent)}
.cxai__rule::after{content:"";display:block;width:1px;height:14px;background:#fff;
  animation:cxai-drop 2.2s cubic-bezier(.4,0,.2,1) infinite}
@keyframes cxai-drop{0%{transform:translateY(0);opacity:0}
  30%{opacity:1}100%{transform:translateY(46px);opacity:0}}

/* chapters */
.cxai__chapters{position:absolute;left:clamp(20px,4vw,64px);bottom:clamp(64px,9vh,104px);
  display:grid}
.cxai__chapter{grid-area:1/1;font-family:Eurostile,system-ui,sans-serif;font-weight:500;
  font-size:11px;letter-spacing:.34em;text-transform:uppercase;color:rgba(255,255,255,.82);
  white-space:nowrap;text-shadow:0 1px 14px rgba(0,0,0,.9),0 0 3px rgba(0,0,0,.6)}

/* outro */
.cxai__outro{position:absolute;left:0;right:0;bottom:clamp(52px,9vh,96px);
  display:flex;flex-direction:column;align-items:center;gap:18px;text-align:center;padding:0 24px}
.cxai__outro h3{font-family:Eurostile,system-ui,sans-serif;font-weight:500;
  font-size:clamp(19px,2.5vw,30px);line-height:1.25;letter-spacing:-.01em;margin:0;
  color:rgba(255,255,255,.94)}
.cxai__cta{display:inline-flex;align-items:center;gap:14px;
  font-family:Eurostile,system-ui,sans-serif;font-weight:700;font-size:12px;
  letter-spacing:.26em;text-transform:uppercase;color:#000;background:#fff;
  padding:15px 26px;text-decoration:none;border:1px solid #fff;
  transition:background .35s ease,color .35s ease}
.cxai__cta span{transition:transform .35s cubic-bezier(.2,.8,.2,1)}
.cxai__cta:hover{background:transparent;color:#fff}
.cxai__cta:hover span{transform:translateX(7px)}
.cxai__cta[data-arrow="down"]:hover span{transform:translateY(5px)}
.cxai__cta:focus-visible{outline:2px solid #fff;outline-offset:4px}

/* progress + counter */
.cxai__bar{position:absolute;left:0;right:0;bottom:0;height:1px;background:rgba(255,255,255,.14)}
.cxai__bar i{display:block;height:100%;width:100%;background:#fff;
  transform:scaleX(0);transform-origin:0 50%;will-change:transform}
.cxai__count{position:absolute;right:clamp(20px,4vw,64px);bottom:clamp(64px,9vh,104px);
  font-family:Eurostile,system-ui,sans-serif;font-weight:500;font-size:11px;
  letter-spacing:.3em;color:rgba(255,255,255,.7);font-variant-numeric:tabular-nums;
  text-shadow:0 1px 14px rgba(0,0,0,.9),0 0 3px rgba(0,0,0,.6)}

/* loading */
.cxai__load{position:absolute;left:50%;bottom:clamp(64px,9vh,104px);transform:translateX(-50%);
  font-family:Eurostile,system-ui,sans-serif;font-size:10px;letter-spacing:.34em;
  text-transform:uppercase;color:rgba(255,255,255,.45);transition:opacity .5s ease}
.cxai.is-ready .cxai__load{opacity:0}

/* header dim while immersive (uses the site header's own transition) */
html.cxai-immersive header{opacity:0!important;pointer-events:none!important}

/* mobile */
@media (max-width:767px){
  .cxai__track{height:210vh}
  @supports (height:100svh){.cxai__track{height:calc(100svh + 110vh)}}
  .cxai__chapters{left:20px;bottom:auto;top:calc(50% - 30vw - 56px)}
  .cxai__count{display:none}
  .cxai__outro{bottom:clamp(40px,7vh,72px);gap:14px}
  .cxai__cta{padding:14px 22px;font-size:11px;letter-spacing:.22em}
}

/* reduced motion */
@media (prefers-reduced-motion:reduce){
  .cxai__scrim{display:none}
  .cxai__track{height:auto!important}
  .cxai__stage{position:relative;height:auto;min-height:78vh;padding:14vh 0}
  .cxai__canvas{position:relative;height:auto;aspect-ratio:16/9;opacity:1;transition:none}
  .cxai__intro,.cxai__chapters,.cxai__bar,.cxai__count,.cxai__load{display:none}
  .cxai__outro{position:relative;bottom:auto;margin-top:34px;opacity:1!important;transform:none!important}
  .cxai__rule::after{animation:none}
}
`;

export default function AiCreativity({
  href = '/reviews',
  ctaLabel = 'Explore our AI work',
  ctaArrow = '\u2192',
  dimHeader = true,
  basePath = '/ai-creativity',
}) {
  const rootRef = useRef(null);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;

    /* ---------- inject scoped styles once ---------- */
    if (!document.getElementById('cxai-styles')) {
      const s = document.createElement('style');
      s.id = 'cxai-styles';
      s.textContent = CSS;
      document.head.appendChild(s);
    }

    const q = (sel) => root.querySelector(sel);
    const canvas   = q('.cxai__canvas');
    const track    = q('.cxai__track');
    const intro    = q('.cxai__intro');
    const outro    = q('.cxai__outro');
    const barFill  = q('.cxai__bar i');
    const counter  = q('.cxai__count');
    const loadEl   = q('.cxai__load');
    const vig      = q('.cxai__vig');
    const chapters = [...root.querySelectorAll('.cxai__chapter')];
    const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    let onScrollImmersiveRef = () => {};

    /* ---------- pick the frame set ---------- */
    const isMobile = window.matchMedia('(max-width: 767px)').matches ||
                     (navigator.maxTouchPoints > 0 && window.innerWidth < 900);
    const SET = isMobile ? SETS.mobile : SETS.desktop;
    const MAP = SET.map;
    const SLOTS = MAP.length;                 // 121 timeline slots
    const COUNT = Math.max(...MAP) + 1;       // unique files
    const frames = new Array(COUNT).fill(null);

    let ready = false, drawnAsset = -1, lastFit = null;
    let target = 0, current = 0, running = false, active = false;
    let vw = 0, vh = 0, dpr = 1;
    let destroyed = false;

    /* ---------- sizing ---------- */
    const measure = () => {
      const r = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      vw = Math.max(1, Math.round(r.width));
      vh = Math.max(1, Math.round(r.height));
      canvas.width  = Math.round(vw * dpr);
      canvas.height = Math.round(vh * dpr);
      drawnAsset = -1; lastFit = null;
    };

    /* ---------- painting ---------- */
    // Early on the frame is full-bleed (cover, softly capped so the logo is
    // never cropped). As the animation resolves it eases toward a contained,
    // slightly lifted composition so the final COSMiC lockup is fully visible
    // with room for the copy beneath it.
    // Average colour of a frame's outer edge, so the letterboxed backdrop is
    // the frame's own black rather than page black — kills the "pasted
    // rectangle" seam completely.
    const bgCache = new Map();
    const bgOf = (assetIdx, img) => {
      if (bgCache.has(assetIdx)) return bgCache.get(assetIdx);
      let rgb = [0, 0, 0];
      try {
        const c = document.createElement('canvas');
        c.width = 1; c.height = 1;
        const x = c.getContext('2d', { willReadFrequently: true });
        x.drawImage(img, 0, 0, Math.round(SET.w * 0.09), Math.round(SET.h * 0.09), 0, 0, 1, 1);
        const d = x.getImageData(0, 0, 1, 1).data;
        rgb = [d[0], d[1], d[2]];
      } catch (e) { /* tainted canvas — fall back to black */ }
      bgCache.set(assetIdx, rgb);
      return rgb;
    };

    const paint = (p, assetIdx, force) => {
      const img = frames[assetIdx];
      if (!img) return;
      const settle = smooth(range(p, 0.70, 0.92));
      const fitKey = `${assetIdx}|${settle.toFixed(3)}|${vw}x${vh}`;
      if (!force && fitKey === lastFit) return;
      lastFit = fitKey;

      const iw = SET.w, ih = SET.h;
      const contain = Math.min(vw / iw, vh / ih);
      const cover   = Math.max(vw / iw, vh / ih);
      const openScale  = Math.min(cover, contain * 1.22);
      const finalScale = contain * (isMobile ? 1 : 0.8);
      const scale = openScale + (finalScale - openScale) * settle;
      const lift  = (isMobile ? 0.13 : 0.055) * vh * settle;

      const dw = iw * scale, dh = ih * scale;
      const dx = (vw - dw) / 2, dy = (vh - dh) / 2 - lift;

      const [br, bg, bb] = bgOf(assetIdx, img);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = `rgb(${Math.round(br * settle)},${Math.round(bg * settle)},${Math.round(bb * settle)})`;
      ctx.fillRect(0, 0, vw, vh);
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, dx, dy, dw, dh);

      // Once the frame is no longer full-bleed, feather its edges into the
      // page black so the letterbox never reads as a pasted-in rectangle.
      if (settle > 0.001) {
        const fx = Math.min(dw * 0.05, 70) * settle;
        const fy = Math.min(dh * 0.06, 52) * settle;
        const c0 = `rgba(${br},${bg},${bb},1)`, c1 = `rgba(${br},${bg},${bb},0)`;
        const edge = (x, y, w, h, x0, y0, x1, y1) => {
          const g = ctx.createLinearGradient(x0, y0, x1, y1);
          g.addColorStop(0, c0);
          g.addColorStop(1, c1);
          ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
        };
        edge(dx, dy, dw, fy, 0, dy, 0, dy + fy);                       // top
        edge(dx, dy + dh - fy, dw, fy, 0, dy + dh, 0, dy + dh - fy);   // bottom
        edge(dx, dy, fx, dh, dx, 0, dx + fx, 0);                       // left
        edge(dx + dw - fx, dy, fx, dh, dx + dw, 0, dx + dw - fx, 0);   // right
      }
    };

    /* nearest already-loaded asset, so fast scrolling never shows a blank */
    const nearestLoaded = (i) => {
      if (frames[i]) return i;
      for (let d = 1; d < COUNT; d++) {
        if (frames[i - d]) return i - d;
        if (frames[i + d]) return i + d;
      }
      return -1;
    };

    /* ---------- overlay state ---------- */
    const setOverlays = (p) => {
      const introOut = smooth(range(p, 0.0, 0.11));
      intro.style.opacity   = String(1 - introOut);
      intro.style.transform = `translateY(${introOut * -22}px)`;
      intro.style.filter    = `blur(${introOut * 5}px)`;

      chapters.forEach((el, i) => {
        const c = CHAPTERS[i];
        const a = smooth(range(p, c.in, c.in + 0.05)) *
                  (1 - smooth(range(p, c.out - 0.05, c.out)));
        el.style.opacity   = String(a);
        el.style.transform = `translateY(${(1 - a) * 8}px)`;
      });

      const o = smooth(range(p, 0.86, 0.97));
      outro.style.opacity   = String(o);
      outro.style.transform = `translateY(${(1 - o) * 22}px)`;
      outro.style.pointerEvents = o > 0.6 ? 'auto' : 'none';

      // UI recedes as the logo takes over
      const recede = smooth(range(p, 0.88, 1));
      barFill.parentElement.style.opacity = String(1 - recede * 0.85);
      counter.style.opacity = String(1 - recede);
      if (vig) vig.style.opacity = String(1 - smooth(range(p, 0.70, 0.92)));

      barFill.style.transform = `scaleX(${p})`;
      counter.textContent = `${String(Math.round(p * 100)).padStart(3, '0')} / 100`;
    };

    /* ---------- scroll -> progress ---------- */
    const readProgress = () => {
      const r = track.getBoundingClientRect();
      const dist = r.height - window.innerHeight;
      if (dist <= 0) return 0;
      return clamp(-r.top / dist);
    };

    const tick = () => {
      if (destroyed) return;
      const d = target - current;
      // Lerp for silk; snap when we're within a sub-frame of the target so a
      // stopped scroll parks on an exact frame and never creeps.
      current = Math.abs(d) < 0.0006 ? target : current + d * 0.16;

      const slot = Math.round(current * (SLOTS - 1));
      const want = MAP[slot];
      const have = nearestLoaded(want);
      if (have >= 0 && (have !== drawnAsset || !ready)) {
        paint(current, have, true);
        drawnAsset = have;
      } else if (have >= 0) {
        paint(current, have, false); // fit may still be easing
      }
      setOverlays(current);
      onScrollImmersiveRef();

      if (current !== target || !ready) {
        requestAnimationFrame(tick);
      } else {
        running = false;
      }
    };

    const kick = () => { if (!running) { running = true; requestAnimationFrame(tick); } };

    const onScroll = () => {
      if (!active) return;
      target = readProgress();
      kick();
    };

    /* ---------- immersive header dim ---------- */
    // The header stays put when the visitor first lands — nav is available —
    // and only clears once they have committed to the film. Hysteresis stops
    // it flickering at the threshold.
    let immersive = false;
    const setImmersive = (pinned) => {
      if (!dimHeader) return;
      const p = current;
      const want = pinned && (immersive ? p > 0.04 : p > 0.08);
      if (want === immersive) return;
      immersive = want;
      document.documentElement.classList.toggle('cxai-immersive', want);
    };

    /* ---------- loading ---------- */
    const url = (i) => `${basePath}/${SET.dir}/f${String(i).padStart(3, '0')}.webp`;

    let loaded = 0;
    const load = (i) => new Promise((res) => {
      const img = new Image();
      img.decoding = 'async';
      img.src = url(i);
      const done = () => {
        frames[i] = img;
        loaded++;
        if (loadEl) loadEl.textContent = `Loading ${Math.round((loaded / COUNT) * 100)}%`;
        res();
      };
      if (img.decode) img.decode().then(done).catch(done);
      else { img.onload = done; img.onerror = () => { loaded++; res(); }; }
    });

    let started = false;
    const preload = async () => {
      if (started) return;
      started = true;

      // first + last frames first: something correct is on screen immediately
      await Promise.all([load(0), load(COUNT - 1)]);
      if (destroyed) return;
      root.classList.add('is-ready');
      ready = true;
      measure();
      target = readProgress(); current = target;
      kick();

      const queue = [];
      for (let i = 1; i < COUNT - 1; i++) queue.push(i);
      const CONC = 6;
      let cursor = 0;
      const worker = async () => {
        while (cursor < queue.length && !destroyed) await load(queue[cursor++]);
      };
      await Promise.all(Array.from({ length: CONC }, worker));
      drawnAsset = -1; kick();
    };

    /* ---------- reduced motion: static, no pin, no scrub ---------- */
    if (reduced.matches) {
      root.classList.add('is-ready');
      load(COUNT - 1).then(() => {
        measure();
        paint(1, COUNT - 1, true);
        setOverlays(1);
      });
      const ro = new ResizeObserver(() => { measure(); paint(1, COUNT - 1, true); });
      ro.observe(canvas);
      return () => { ro.disconnect(); destroyed = true; };
    }

    /* ---------- observers ---------- */
    // Start fetching a viewport early; only listen to scroll while in view.
    const near = new IntersectionObserver((es) => {
      if (es.some((e) => e.isIntersecting)) preload();
    }, { rootMargin: '100% 0px' });
    near.observe(root);

    const inView = new IntersectionObserver((es) => {
      active = es[0].isIntersecting;
      if (active) { target = readProgress(); kick(); }
      const r = track.getBoundingClientRect();
      setImmersive(active && r.top <= 8 && r.bottom >= window.innerHeight - 8);
    }, { threshold: [0, 0.01, 0.5, 0.99] });
    inView.observe(track);

    const onScrollImmersive = () => {
      const r = track.getBoundingClientRect();
      setImmersive(r.top <= 8 && r.bottom >= window.innerHeight - 8);
    };
    onScrollImmersiveRef = onScrollImmersive;
    const scrollHandler = () => { onScroll(); onScrollImmersive(); };

    window.addEventListener('scroll', scrollHandler, { passive: true });

    const ro = new ResizeObserver(() => { measure(); drawnAsset = -1; kick(); });
    ro.observe(canvas);

    measure();
    setOverlays(0);
    onScrollImmersive();

    return () => {
      destroyed = true;
      window.removeEventListener('scroll', scrollHandler);
      near.disconnect(); inView.disconnect(); ro.disconnect();
      document.documentElement.classList.remove('cxai-immersive');
    };
  }, [dimHeader, basePath]);

  return (
    <section id="ai-creativity" className="cxai" ref={rootRef} aria-label="AI Creativity">
      <div className="cxai__track">
        <div className="cxai__stage">
          <canvas className="cxai__canvas" aria-hidden="true" />
          <div className="cxai__vig" aria-hidden="true" />
          <div className="cxai__scrim" aria-hidden="true" />
          <div className="cxai__grain" aria-hidden="true" />

          <div className="cxai__ui">
            <div className="cxai__intro">
              <h2 className="cxai__title">AI Creativity</h2>
              <div className="cxai__hint">
                <p className="cxai__eyebrow">Scroll to explore</p>
                <span className="cxai__rule" aria-hidden="true" />
              </div>
            </div>

            <div className="cxai__chapters" aria-hidden="true">
              {CHAPTERS.map((c) => (
                <span className="cxai__chapter" key={c.t}>{c.t}</span>
              ))}
            </div>

            <div className="cxai__outro">
              {/* no eyebrow here — the final video frame already renders
                  "AI CREATIVITY" beneath the logo; repeating it would double up */}
              <h3>Where ideas become visuals.</h3>
              <a className="cxai__cta" href={href}
                 data-arrow={ctaArrow === '\u2193' ? 'down' : 'right'}>
                {ctaLabel} <span aria-hidden="true">{ctaArrow}</span>
              </a>
            </div>

            <p className="cxai__load">Loading</p>
            <div className="cxai__count">000 / 100</div>
            <div className="cxai__bar" aria-hidden="true"><i /></div>
          </div>
        </div>
      </div>
    </section>
  );
}
